package com.example.anchor.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.navigation.NavController
import com.example.anchor.data.DataStore
import com.example.anchor.health.WearableHealth
import kotlinx.coroutines.launch
import java.time.Duration
import java.time.Instant
import kotlin.math.roundToInt

/**
 * Reads pulse and vitals from a watch or ring via Health Connect.
 * During a panic attack this is the calmest option: no holding a finger
 * on the camera — the wearable already has the data.
 */
@Composable
fun WearableScreen(nav: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var sdkStatus by remember { mutableStateOf(WearableHealth.sdkStatus(context)) }
    var connected by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var snapshot by remember { mutableStateOf<WearableHealth.Snapshot?>(null) }
    var saved by remember { mutableStateOf(false) }

    val refresh: () -> Unit = {
        scope.launch {
            loading = true
            sdkStatus = WearableHealth.sdkStatus(context)
            if (sdkStatus == HealthConnectClient.SDK_AVAILABLE) {
                connected = WearableHealth.hasHeartRatePermission(context)
                if (connected) {
                    snapshot = try {
                        WearableHealth.readSnapshot(context)
                    } catch (e: Exception) {
                        null
                    }
                    saved = false
                }
            }
            loading = false
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        PermissionController.createRequestPermissionResultContract()
    ) { refresh() }

    LaunchedEffect(Unit) { refresh() }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
    ) {
        ScreenHeader("Watch & ring") { nav.popBackStack() }

        when {
            sdkStatus == HealthConnectClient.SDK_UNAVAILABLE -> {
                InfoCard(
                    "Not available on this device",
                    "Reading from watches and rings uses Health Connect, which needs Android 9 or newer."
                )
            }

            sdkStatus == HealthConnectClient.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED -> {
                InfoCard(
                    "One more step",
                    "Health Connect needs to be installed or updated before Anchor can read from your watch or ring."
                )
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = { openHealthConnectInStore(context) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                ) { Text("Get Health Connect") }
            }

            !connected -> {
                InfoCard(
                    "Your wearable already has your pulse",
                    "Anchor can read heart rate, HRV, blood oxygen and breathing rate from " +
                        "anything that syncs to Health Connect — Pixel Watch, Galaxy Watch " +
                        "and Galaxy Ring, Fitbit, Garmin, Oura and more.\n\n" +
                        "Mid-panic, that means no fiddling with the camera: just open this " +
                        "screen and see your numbers."
                )
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = { permissionLauncher.launch(WearableHealth.PERMISSIONS) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                ) { Text("Connect Health Connect") }
                Text(
                    "Anchor only reads. Your data stays on this phone.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp)
                )
            }

            else -> {
                WearableData(
                    snapshot = snapshot,
                    loading = loading,
                    saved = saved,
                    onRefresh = refresh,
                    onSave = { latest ->
                        DataStore.addReading(
                            context,
                            DataStore.Reading(latest.time.toEpochMilli(), latest.bpm, "watch")
                        )
                        saved = true
                    },
                    onCameraPulse = { nav.navigate("pulse") }
                )
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun WearableData(
    snapshot: WearableHealth.Snapshot?,
    loading: Boolean,
    saved: Boolean,
    onRefresh: () -> Unit,
    onSave: (WearableHealth.HrPoint) -> Unit,
    onCameraPulse: () -> Unit
) {
    val latest = snapshot?.latestHr
    val recent = snapshot?.recentHr ?: emptyList()

    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            if (latest != null) {
                Text(
                    "${latest.bpm}",
                    style = MaterialTheme.typography.displayLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    "bpm \u00b7 ${timeAgo(latest.time)}" +
                        (snapshot.sourceApp?.let { " \u00b7 via $it" } ?: ""),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (recent.size >= 2) {
                    Spacer(Modifier.height(14.dp))
                    val values = recent.map { it.bpm.toFloat() }
                    val mn = values.minOrNull() ?: 0f
                    val mx = values.maxOrNull() ?: 0f
                    val range = (mx - mn).coerceAtLeast(1f)
                    WaveLine(
                        values.map { (it - mn) / range },
                        Modifier
                            .fillMaxWidth()
                            .height(90.dp)
                    )
                    Text(
                        "${mn.roundToInt()}\u2013${mx.roundToInt()} bpm \u00b7 last hour",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
            } else if (loading) {
                Text(
                    "Reading from Health Connect\u2026",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Text(
                    "No heart-rate data synced yet. Open your watch or ring's own app once " +
                        "so it syncs to Health Connect, then refresh.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        }
    }

    // Honesty about freshness: Health Connect data arrives by sync, not live.
    if (latest != null && Duration.between(latest.time, Instant.now()).toMinutes() > 10) {
        Spacer(Modifier.height(10.dp))
        Text(
            "This reading is from a while ago — wearables sync every few minutes. " +
                "Open your watch/ring's app to force a sync, or use the camera pulse for a live number.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        OutlinedButton(onClick = onCameraPulse, modifier = Modifier.padding(top = 8.dp)) {
            Text("Take a live camera reading")
        }
    }

    Spacer(Modifier.height(14.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        StatCell("Resting HR", snapshot?.restingHr?.let { "$it bpm" }, Modifier.weight(1f))
        StatCell("HRV (RMSSD)", snapshot?.hrvMs?.let { "${it.roundToInt()} ms" }, Modifier.weight(1f))
    }
    Spacer(Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        StatCell("Blood oxygen", snapshot?.spo2?.let { "${it.roundToInt()}%" }, Modifier.weight(1f))
        StatCell("Breathing", snapshot?.respRate?.let { "${it.roundToInt()}/min" }, Modifier.weight(1f))
    }
    Text(
        "Latest values from the past 24 hours, as synced by your wearable's app.",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(top = 8.dp)
    )

    Spacer(Modifier.height(16.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedButton(
            onClick = onRefresh,
            enabled = !loading,
            modifier = Modifier
                .weight(1f)
                .height(52.dp)
        ) { Text(if (loading) "Refreshing\u2026" else "Refresh") }
        Button(
            onClick = { latest?.let(onSave) },
            enabled = latest != null && !saved,
            modifier = Modifier
                .weight(1f)
                .height(52.dp)
        ) { Text(if (saved) "Saved \u2713" else "Save to log") }
    }
    if (saved) {
        Text(
            "Saved — it will attach to your next episode log if recent.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 8.dp)
        )
    }
}

@Composable
private fun StatCell(label: String, value: String?, modifier: Modifier = Modifier) {
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        modifier = modifier
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(
                label,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(4.dp))
            Text(value ?: "\u2014", style = MaterialTheme.typography.titleLarge)
        }
    }
}

private fun openHealthConnectInStore(context: Context) {
    val pkg = "com.google.android.apps.healthdata"
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg")))
    } catch (e: Exception) {
        context.startActivity(
            Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$pkg"))
        )
    }
}

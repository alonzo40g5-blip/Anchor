package com.example.anchor.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// "Dusk" palette — deep night blues with a soft aqua accent.
// Chosen for low visual arousal: panic attacks often happen at night,
// and a bright white screen is the last thing anyone needs.
val Night = Color(0xFF0C1622)
val NightRaised = Color(0xFF152238)
val Mist = Color(0xFFE8F1F5)
val MistDim = Color(0xFF9FB4C4)
val Aqua = Color(0xFF7FD8CD)
val AquaDeep = Color(0xFF0F3D3B)
val Sand = Color(0xFFEFC998)
val Rose = Color(0xFFE98B8B)

private val AnchorColors = darkColorScheme(
    primary = Aqua,
    onPrimary = Color(0xFF06201E),
    primaryContainer = AquaDeep,
    onPrimaryContainer = Aqua,
    secondary = Sand,
    onSecondary = Color(0xFF2A1F0E),
    background = Night,
    onBackground = Mist,
    surface = NightRaised,
    onSurface = Mist,
    surfaceVariant = Color(0xFF1B2A44),
    onSurfaceVariant = MistDim,
    error = Rose,
    outline = Color(0xFF33475F)
)

val AnchorShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp)
)

val AnchorTypography = Typography(
    displayLarge = TextStyle(fontSize = 64.sp, fontWeight = FontWeight.Light, letterSpacing = (-1).sp),
    headlineMedium = TextStyle(fontSize = 26.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.5).sp),
    titleLarge = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 21.sp),
    labelLarge = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.Medium)
)

@Composable
fun AnchorTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AnchorColors,
        shapes = AnchorShapes,
        typography = AnchorTypography,
        content = content
    )
}

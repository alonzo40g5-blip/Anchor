package com.example.anchor.health

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.HeartRateVariabilityRmssdRecord
import androidx.health.connect.client.records.OxygenSaturationRecord
import androidx.health.connect.client.records.Record
import androidx.health.connect.client.records.RespiratoryRateRecord
import androidx.health.connect.client.records.RestingHeartRateRecord
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import java.time.Instant
import kotlin.reflect.KClass

/**
 * Reads vitals from Health Connect — the shared health data layer on Android.
 * Watches and rings (Pixel Watch, Galaxy Watch/Ring, Fitbit, Garmin, Oura, ...)
 * sync their measurements into Health Connect via their own companion apps;
 * Anchor only reads from it, and only with the user's explicit permission.
 */
object WearableHealth {

    data class HrPoint(val time: Instant, val bpm: Int)

    data class Snapshot(
        val latestHr: HrPoint?,
        val recentHr: List<HrPoint>,   // last hour, ascending by time
        val restingHr: Int?,           // latest in 24 h
        val hrvMs: Double?,            // latest RMSSD in 24 h
        val spo2: Double?,             // latest blood oxygen % in 24 h
        val respRate: Double?,         // latest breaths/min in 24 h
        val sourceApp: String?
    )

    val PERMISSIONS = setOf(
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(RestingHeartRateRecord::class),
        HealthPermission.getReadPermission(HeartRateVariabilityRmssdRecord::class),
        HealthPermission.getReadPermission(OxygenSaturationRecord::class),
        HealthPermission.getReadPermission(RespiratoryRateRecord::class)
    )

    fun sdkStatus(context: Context): Int = HealthConnectClient.getSdkStatus(context)

    private fun client(context: Context): HealthConnectClient =
        HealthConnectClient.getOrCreate(context)

    /** Heart rate is the one permission Anchor actually needs; the rest are nice-to-have. */
    suspend fun hasHeartRatePermission(context: Context): Boolean = try {
        client(context).permissionController.getGrantedPermissions()
            .contains(HealthPermission.getReadPermission(HeartRateRecord::class))
    } catch (e: Exception) {
        false
    }

    suspend fun readSnapshot(context: Context): Snapshot {
        val c = client(context)
        val now = Instant.now()
        val hourAgo = now.minusSeconds(3600)
        val dayAgo = now.minusSeconds(24 * 3600)

        val points = mutableListOf<HrPoint>()
        var sourcePkg: String? = null

        // All heart-rate samples from the last hour (for the sparkline).
        try {
            val response = c.readRecords(
                ReadRecordsRequest(HeartRateRecord::class, timeRangeFilter = TimeRangeFilter.between(hourAgo, now))
            )
            for (record in response.records) {
                if (sourcePkg == null) sourcePkg = record.metadata.dataOrigin.packageName
                for (sample in record.samples) {
                    points.add(HrPoint(sample.time, sample.beatsPerMinute.toInt()))
                }
            }
        } catch (e: Exception) {
            // Permission missing or Health Connect hiccup — fall through with empty data.
        }

        // If the watch hasn't synced within the hour, at least surface the newest sample of the day.
        if (points.isEmpty()) {
            c.latest(HeartRateRecord::class, dayAgo, now)?.let { record ->
                if (sourcePkg == null) sourcePkg = record.metadata.dataOrigin.packageName
                record.samples.maxByOrNull { it.time }?.let {
                    points.add(HrPoint(it.time, it.beatsPerMinute.toInt()))
                }
            }
        }
        points.sortBy { it.time }

        val resting = c.latest(RestingHeartRateRecord::class, dayAgo, now)?.beatsPerMinute?.toInt()
        val hrv = c.latest(HeartRateVariabilityRmssdRecord::class, dayAgo, now)?.heartRateVariabilityMillis
        val spo2 = c.latest(OxygenSaturationRecord::class, dayAgo, now)?.percentage?.value
        val resp = c.latest(RespiratoryRateRecord::class, dayAgo, now)?.rate

        return Snapshot(
            latestHr = points.lastOrNull(),
            recentHr = points,
            restingHr = resting,
            hrvMs = hrv,
            spo2 = spo2,
            respRate = resp,
            sourceApp = prettySource(sourcePkg)
        )
    }

    private suspend fun <T : Record> HealthConnectClient.latest(
        type: KClass<T>,
        start: Instant,
        end: Instant
    ): T? = try {
        readRecords(
            ReadRecordsRequest(
                type,
                timeRangeFilter = TimeRangeFilter.between(start, end),
                ascendingOrder = false,
                pageSize = 1
            )
        ).records.firstOrNull()
    } catch (e: Exception) {
        null
    }

    private fun prettySource(pkg: String?): String? = when (pkg) {
        null -> null
        "com.sec.android.app.shealth" -> "Samsung Health"
        "com.google.android.apps.fitness" -> "Google Fit"
        "com.fitbit.FitbitMobile" -> "Fitbit"
        "com.garmin.android.apps.connectmobile" -> "Garmin Connect"
        "com.ouraring.oura" -> "Oura"
        "com.google.android.apps.healthdata" -> "Health Connect"
        else -> pkg.substringAfterLast('.').replaceFirstChar { it.uppercase() }
    }
}

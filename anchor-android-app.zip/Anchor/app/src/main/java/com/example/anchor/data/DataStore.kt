package com.example.anchor.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Tiny on-device store. Everything lives in one JSON file in the app's
 * private storage — nothing ever leaves the phone.
 */
object DataStore {

    /** A single pulse reading. source is "camera" or "watch". */
    data class Reading(val time: Long, val bpm: Int, val source: String = "camera")

    /** One logged panic episode. */
    data class Episode(
        val time: Long,
        val intensity: Int,
        val symptoms: List<String>,
        val bpm: Int?,
        val notes: String
    )

    private const val FILE_NAME = "anchor_data.json"

    private fun file(context: Context) = File(context.filesDir, FILE_NAME)

    private fun root(context: Context): JSONObject = try {
        JSONObject(file(context).readText())
    } catch (e: Exception) {
        JSONObject().put("readings", JSONArray()).put("episodes", JSONArray())
    }

    private fun save(context: Context, root: JSONObject) {
        file(context).writeText(root.toString())
    }

    fun readings(context: Context): List<Reading> {
        val arr = root(context).optJSONArray("readings") ?: JSONArray()
        val out = mutableListOf<Reading>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(Reading(o.getLong("t"), o.getInt("b"), o.optString("src", "camera")))
        }
        return out.sortedByDescending { it.time }
    }

    fun episodes(context: Context): List<Episode> {
        val arr = root(context).optJSONArray("episodes") ?: JSONArray()
        val out = mutableListOf<Episode>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val symptoms = mutableListOf<String>()
            val sArr = o.optJSONArray("s") ?: JSONArray()
            for (j in 0 until sArr.length()) symptoms.add(sArr.getString(j))
            out.add(
                Episode(
                    time = o.getLong("t"),
                    intensity = o.optInt("i", 5),
                    symptoms = symptoms,
                    bpm = if (o.has("b")) o.getInt("b") else null,
                    notes = o.optString("n", "")
                )
            )
        }
        return out.sortedByDescending { it.time }
    }

    fun addReading(context: Context, reading: Reading) {
        val r = root(context)
        val arr = r.optJSONArray("readings") ?: JSONArray().also { r.put("readings", it) }
        arr.put(JSONObject().put("t", reading.time).put("b", reading.bpm).put("src", reading.source))
        save(context, r)
    }

    fun addEpisode(context: Context, e: Episode) {
        val r = root(context)
        val arr = r.optJSONArray("episodes") ?: JSONArray().also { r.put("episodes", it) }
        val o = JSONObject()
            .put("t", e.time)
            .put("i", e.intensity)
            .put("s", JSONArray(e.symptoms))
            .put("n", e.notes)
        if (e.bpm != null) o.put("b", e.bpm)
        arr.put(o)
        save(context, r)
    }

    fun deleteReading(context: Context, time: Long) = deleteBy(context, "readings", time)
    fun deleteEpisode(context: Context, time: Long) = deleteBy(context, "episodes", time)

    private fun deleteBy(context: Context, key: String, time: Long) {
        val r = root(context)
        val arr = r.optJSONArray(key) ?: return
        val kept = JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.getLong("t") != time) kept.put(o)
        }
        r.put(key, kept)
        save(context, r)
    }

    /** Newest reading taken within [windowMs] of now — auto-attached when logging an episode. */
    fun latestRecentReading(context: Context, windowMs: Long): Reading? {
        val now = System.currentTimeMillis()
        return readings(context).firstOrNull { now - it.time <= windowMs }
    }
}

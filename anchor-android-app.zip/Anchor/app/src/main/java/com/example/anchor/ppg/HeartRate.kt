package com.example.anchor.ppg

import androidx.camera.core.ImageProxy
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Photoplethysmography (PPG): with a fingertip pressed over the rear camera and
 * flash, each heartbeat pushes a tiny bit more blood into the finger, absorbing
 * slightly more light. The frame brightness therefore pulses in time with the
 * heart. We track that brightness, detrend it, find the peaks, and turn the
 * intervals between peaks into beats-per-minute.
 */

/**
 * Mean brightness and spatial standard deviation of the center region of a
 * YUV_420_888 frame (Y plane only). The spatial std-dev tells us whether a
 * finger is actually covering the lens — a covered lens is very uniform.
 */
fun frameStats(image: ImageProxy): Pair<Double, Double> {
    val plane = image.planes[0]
    val buffer = plane.buffer
    val rowStride = plane.rowStride
    val pixelStride = plane.pixelStride
    val width = image.width
    val height = image.height
    val cx = width / 2
    val cy = height / 2
    val half = min(width, height) / 4

    var sum = 0.0
    var sumSq = 0.0
    var count = 0
    var y = cy - half
    while (y < cy + half) {
        val base = y * rowStride
        var x = cx - half
        while (x < cx + half) {
            val p = (buffer.get(base + x * pixelStride).toInt() and 0xFF).toDouble()
            sum += p
            sumSq += p * p
            count++
            x += 6
        }
        y += 6
    }
    if (count == 0) return 0.0 to 0.0
    val mean = sum / count
    val variance = max(0.0, sumSq / count - mean * mean)
    return mean to sqrt(variance)
}

class HeartRateProcessor {

    enum class Quality { NO_FINGER, SETTLING, WEAK, GOOD }

    data class Snapshot(
        val bpm: Int?,
        val quality: Quality,
        val waveform: List<Float>,
        val beats: Int
    )

    private val rawValues = ArrayDeque<Double>()
    private val filtered = ArrayDeque<Double>()
    private val ibis = ArrayDeque<Long>() // inter-beat intervals, ms

    private var prevVal = 0.0
    private var prevPrevVal = 0.0
    private var prevTime = 0L
    private var lastPeakTime = 0L
    private var beats = 0
    private var lostFrames = 0
    private var goodFrames = 0

    fun reset() {
        rawValues.clear(); filtered.clear(); ibis.clear()
        prevVal = 0.0; prevPrevVal = 0.0; prevTime = 0L
        lastPeakTime = 0L; beats = 0; lostFrames = 0; goodFrames = 0
    }

    fun add(timeMs: Long, mean: Double, spatialStd: Double): Snapshot {
        // A finger over the lens + torch produces a uniform, mid-bright frame.
        val fingerDown = spatialStd < 45.0 && mean in 15.0..250.0
        if (!fingerDown) {
            lostFrames++
            if (lostFrames > 8) reset()
            return Snapshot(null, Quality.NO_FINGER, waveform(), beats)
        }
        lostFrames = 0
        goodFrames++

        rawValues.addLast(mean)
        if (rawValues.size > RAW_WINDOW) rawValues.removeFirst()
        if (rawValues.size < TREND_WINDOW) {
            return Snapshot(null, Quality.SETTLING, waveform(), beats)
        }

        // Detrend: subtract a short moving average so slow drift disappears
        // and only the pulse ripple remains.
        var trend = 0.0
        for (i in rawValues.size - TREND_WINDOW until rawValues.size) trend += rawValues[i]
        trend /= TREND_WINDOW
        val v = mean - trend

        filtered.addLast(v)
        if (filtered.size > FILT_WINDOW) filtered.removeFirst()

        detectPeak(v)

        prevPrevVal = prevVal
        prevVal = v
        prevTime = timeMs

        val bpm = currentBpm()
        val quality = when {
            bpm != null && ibis.size >= 5 && ibiConsistent() -> Quality.GOOD
            goodFrames > 45 -> Quality.WEAK
            else -> Quality.SETTLING
        }
        return Snapshot(bpm, quality, waveform(), beats)
    }

    /** A peak is a local maximum above an adaptive threshold, with a refractory period. */
    private fun detectPeak(current: Double) {
        if (prevTime == 0L) return
        val threshold = max(0.35, 0.55 * filteredStd())
        val isPeak = prevVal > prevPrevVal && prevVal >= current && prevVal > threshold &&
            (lastPeakTime == 0L || prevTime - lastPeakTime > MIN_IBI_MS)
        if (!isPeak) return
        if (lastPeakTime != 0L) {
            val ibi = prevTime - lastPeakTime
            if (ibi in MIN_IBI_MS..MAX_IBI_MS) {
                ibis.addLast(ibi)
                if (ibis.size > IBI_WINDOW) ibis.removeFirst()
                beats++
            }
        }
        lastPeakTime = prevTime
    }

    /** Median of the recent inter-beat intervals — robust against a stray missed/extra beat. */
    private fun currentBpm(): Int? {
        if (ibis.size < 3) return null
        val recent = ibis.toList().takeLast(8).sorted()
        val median = recent[recent.size / 2].toDouble()
        return (60000.0 / median).roundToInt().coerceIn(35, 210)
    }

    private fun ibiConsistent(): Boolean {
        val recent = ibis.toList().takeLast(8)
        if (recent.size < 5) return false
        val mean = recent.average()
        val sd = sqrt(recent.map { (it - mean) * (it - mean) }.average())
        return mean > 0 && sd / mean < 0.30
    }

    private fun filteredStd(): Double {
        if (filtered.size < 10) return 1.0
        var sum = 0.0
        var sumSq = 0.0
        for (x in filtered) { sum += x; sumSq += x * x }
        val n = filtered.size
        val m = sum / n
        return sqrt(max(0.0, sumSq / n - m * m))
    }

    private fun waveform(): List<Float> {
        if (filtered.isEmpty()) return emptyList()
        val pts = filtered.toList().takeLast(WAVE_POINTS)
        val mn = pts.minOrNull() ?: return emptyList()
        val mx = pts.maxOrNull() ?: return emptyList()
        val range = if (mx - mn > 1e-6) mx - mn else 1.0
        return pts.map { ((it - mn) / range).toFloat() }
    }

    companion object {
        private const val RAW_WINDOW = 300     // ~10 s of samples at 30 fps
        private const val TREND_WINDOW = 20    // ~0.7 s moving average
        private const val FILT_WINDOW = 300
        private const val IBI_WINDOW = 12
        private const val MIN_IBI_MS = 280L    // ~214 bpm ceiling
        private const val MAX_IBI_MS = 1600L   // ~37 bpm floor
        private const val WAVE_POINTS = 90
    }
}

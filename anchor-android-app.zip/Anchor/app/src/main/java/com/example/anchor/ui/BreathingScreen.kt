package com.example.anchor.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class PhaseKind { INHALE, HOLD, EXHALE }

data class BreathPhase(val label: String, val seconds: Int, val kind: PhaseKind)

data class Technique(val name: String, val phases: List<BreathPhase>)

val Techniques = listOf(
    Technique(
        "4-7-8",
        listOf(
            BreathPhase("Breathe in", 4, PhaseKind.INHALE),
            BreathPhase("Hold", 7, PhaseKind.HOLD),
            BreathPhase("Breathe out", 8, PhaseKind.EXHALE)
        )
    ),
    Technique(
        "Box",
        listOf(
            BreathPhase("Breathe in", 4, PhaseKind.INHALE),
            BreathPhase("Hold", 4, PhaseKind.HOLD),
            BreathPhase("Breathe out", 4, PhaseKind.EXHALE),
            BreathPhase("Hold", 4, PhaseKind.HOLD)
        )
    ),
    Technique(
        "Slow 5\u00b75",
        listOf(
            BreathPhase("Breathe in", 5, PhaseKind.INHALE),
            BreathPhase("Breathe out", 5, PhaseKind.EXHALE)
        )
    )
)

@Composable
fun BreathingScreen(nav: NavController) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
    ) {
        ScreenHeader("Breathe") { nav.popBackStack() }
        BreathingContent(Modifier.weight(1f))
    }
}

/**
 * The breathing exercise itself, reusable inside the guided calm flow.
 * A long exhale activates the parasympathetic system — the body's own brake.
 */
@Composable
fun BreathingContent(
    modifier: Modifier = Modifier,
    autoStart: Boolean = false,
    showTechniquePicker: Boolean = true
) {
    val context = LocalContext.current
    var techniqueIndex by remember { mutableStateOf(0) }
    var running by remember { mutableStateOf(autoStart) }
    var label by remember { mutableStateOf("Ready when you are") }
    var secondsLeft by remember { mutableStateOf(0) }
    var cycles by remember { mutableStateOf(0) }
    val scale = remember { Animatable(0.6f) }
    val technique = Techniques[techniqueIndex]

    LaunchedEffect(running, techniqueIndex) {
        if (!running) {
            label = "Ready when you are"
            secondsLeft = 0
            scale.snapTo(0.6f)
            return@LaunchedEffect
        }
        cycles = 0
        scale.snapTo(0.6f)
        while (isActive) {
            for (phase in technique.phases) {
                label = phase.label
                gentleTick(context)
                when (phase.kind) {
                    PhaseKind.INHALE -> launch {
                        scale.animateTo(1f, tween(phase.seconds * 1000, easing = FastOutSlowInEasing))
                    }
                    PhaseKind.EXHALE -> launch {
                        scale.animateTo(0.6f, tween(phase.seconds * 1000, easing = FastOutSlowInEasing))
                    }
                    PhaseKind.HOLD -> {}
                }
                for (s in phase.seconds downTo 1) {
                    secondsLeft = s
                    delay(1000)
                }
            }
            cycles++
        }
    }

    val ringColor = MaterialTheme.colorScheme.outline
    val circleInner = MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)
    val circleOuter = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)

    Column(
        modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (showTechniquePicker) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(top = 4.dp)
            ) {
                Techniques.forEachIndexed { i, t ->
                    FilterChip(
                        selected = i == techniqueIndex,
                        onClick = { techniqueIndex = i },
                        label = { Text(t.name) }
                    )
                }
            }
        }
        Spacer(Modifier.weight(1f))
        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(290.dp)) {
            Canvas(Modifier.matchParentSize()) {
                drawCircle(color = ringColor, style = Stroke(width = 2.dp.toPx()))
            }
            Box(
                Modifier
                    .size(250.dp)
                    .graphicsLayer {
                        scaleX = scale.value
                        scaleY = scale.value
                    }
                    .background(Brush.radialGradient(listOf(circleInner, circleOuter)), CircleShape)
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(label, style = MaterialTheme.typography.titleLarge)
                if (secondsLeft > 0) {
                    Text(
                        "$secondsLeft",
                        style = MaterialTheme.typography.displayLarge.copy(fontSize = 44.sp),
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
        Spacer(Modifier.weight(1f))
        Row(verticalAlignment = Alignment.CenterVertically) {
            FilledTonalButton(
                onClick = { running = !running },
                modifier = Modifier.height(52.dp)
            ) { Text(if (running) "Pause" else "Start") }
            Spacer(Modifier.width(16.dp))
            Text(
                "Cycles: $cycles",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.height(20.dp))
    }
}

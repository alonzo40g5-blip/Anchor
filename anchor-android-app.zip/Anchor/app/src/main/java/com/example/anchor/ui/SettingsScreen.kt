package com.example.anchor.ui

import android.content.Context
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun SettingsScreen(nav: NavController) {
    val context = LocalContext.current
    val prefs = context.getSharedPreferences("anchor_prefs", Context.MODE_PRIVATE)
    var name by rememberSaveable { mutableStateOf(prefs.getString("contact_name", "") ?: "") }
    var number by rememberSaveable { mutableStateOf(prefs.getString("contact_number", "") ?: "") }
    var savedNote by rememberSaveable { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
    ) {
        ScreenHeader("Settings") { nav.popBackStack() }

        SectionLabel("Trusted contact")
        Text(
            "One tap on the home screen opens the dialer with this number — for the moments when talking to someone helps most.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = name,
            onValueChange = {
                name = it
                savedNote = false
            },
            label = { Text("Name") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = number,
            onValueChange = {
                number = it
                savedNote = false
            },
            label = { Text("Phone number") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = {
                prefs.edit()
                    .putString("contact_name", name.trim())
                    .putString("contact_number", number.trim())
                    .apply()
                savedNote = true
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) { Text(if (savedNote) "Saved \u2713" else "Save") }

        SectionLabel("About Anchor")
        Text(
            "Anchor is a panic attack companion. It can estimate your pulse with the phone's " +
                "camera and flash (photoplethysmography — the same trick pulse oximeters use), " +
                "read heart rate and vitals your watch or ring has synced to Health Connect, " +
                "guide you through paced breathing and 5-4-3-2-1 grounding, and keep a private " +
                "log of episodes.\n\n" +
                "Everything is stored only on this phone. Health Connect access is read-only " +
                "and can be revoked at any time in the Health Connect settings.\n\n" +
                "Anchor is not a medical device and can't diagnose anything. Camera and " +
                "wearable readings are estimates. If you have chest pain or pressure, pain " +
                "spreading to your arm, jaw or back, fainting, or symptoms unlike your usual " +
                "panic, contact emergency services immediately.\n\n" +
                "Panic disorder is very treatable. If attacks are frequent or limiting your " +
                "life, a doctor or therapist can genuinely help — this app is a companion, " +
                "not a replacement.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(24.dp))
    }
}

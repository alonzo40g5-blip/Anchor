package com.example.anchor.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.SystemClock
import android.util.Size
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import com.example.anchor.data.DataStore
import com.example.anchor.ppg.HeartRateProcessor
import com.example.anchor.ppg.frameStats
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

private enum class MeasurePhase { READY, MEASURING, DONE }

@Composable
fun PulseScreen(nav: NavController) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val view = LocalView.current

    var hasPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    var phase by remember { mutableStateOf(MeasurePhase.READY) }
    var bpm by remember { mutableStateOf<Int?>(null) }
    var finalBpm by remember { mutableStateOf<Int?>(null) }
    var quality by remember { mutableStateOf(HeartRateProcessor.Quality.NO_FINGER) }
    var waveform by remember { mutableStateOf(listOf<Float>()) }
    var progress by remember { mutableStateOf(0f) }
    var saved by remember { mutableStateOf(false) }
    val processor = remember { HeartRateProcessor() }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasPermission = granted
        if (granted) phase = MeasurePhase.MEASURING
    }

    // Keep the screen awake mid-measurement so it doesn't dim under the finger.
    DisposableEffect(phase) {
        view.keepScreenOn = phase == MeasurePhase.MEASURING
        onDispose { view.keepScreenOn = false }
    }

    // Bind / unbind the camera as the phase changes.
    DisposableEffect(phase, hasPermission) {
        var disposed = false
        var provider: ProcessCameraProvider? = null
        if (phase == MeasurePhase.MEASURING && hasPermission) {
            val future = ProcessCameraProvider.getInstance(context)
            future.addListener({
                val p = future.get()
                if (disposed) {
                    p.unbindAll()
                    return@addListener
                }
                provider = p
                val analysis = ImageAnalysis.Builder()
                    .setResolutionSelector(
                        ResolutionSelector.Builder()
                            .setResolutionStrategy(
                                ResolutionStrategy(
                                    Size(320, 240),
                                    ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER
                                )
                            )
                            .build()
                    )
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(ContextCompat.getMainExecutor(context)) { image ->
                    val (mean, std) = frameStats(image)
                    image.close()
                    val snap = processor.add(SystemClock.elapsedRealtime(), mean, std)
                    bpm = snap.bpm
                    quality = snap.quality
                    waveform = snap.waveform
                }
                try {
                    p.unbindAll()
                    val camera = p.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, analysis)
                    if (camera.cameraInfo.hasFlashUnit()) {
                        camera.cameraControl.enableTorch(true)
                    }
                } catch (e: Exception) {
                    phase = MeasurePhase.READY
                }
            }, ContextCompat.getMainExecutor(context))
        }
        onDispose {
            disposed = true
            provider?.unbindAll()
        }
    }

    // 30-second measurement window.
    LaunchedEffect(phase) {
        if (phase == MeasurePhase.MEASURING) {
            processor.reset()
            saved = false
            progress = 0f
            val duration = 30_000L
            val start = SystemClock.elapsedRealtime()
            while (isActive) {
                val elapsed = SystemClock.elapsedRealtime() - start
                progress = (elapsed / duration.toFloat()).coerceIn(0f, 1f)
                if (elapsed >= duration) break
                delay(100)
            }
            finalBpm = bpm
            phase = MeasurePhase.DONE
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
    ) {
        ScreenHeader("Pulse") { nav.popBackStack() }
        when (phase) {
            MeasurePhase.READY -> ReadyView(
                onStart = {
                    if (hasPermission) phase = MeasurePhase.MEASURING
                    else permissionLauncher.launch(Manifest.permission.CAMERA)
                },
                onWearable = { nav.navigate("wearable") }
            )
            MeasurePhase.MEASURING -> MeasuringView(bpm, quality, waveform, progress) {
                phase = MeasurePhase.READY
            }
            MeasurePhase.DONE -> DoneView(
                finalBpm = finalBpm,
                saved = saved,
                onSave = {
                    finalBpm?.let {
                        DataStore.addReading(context, DataStore.Reading(System.currentTimeMillis(), it, "camera"))
                        saved = true
                    }
                },
                onAgain = { phase = MeasurePhase.MEASURING },
                onBreathe = { nav.navigate("breathe") }
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun ReadyView(onStart: () -> Unit, onWearable: () -> Unit) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(12.dp))
        Surface(
            shape = MaterialTheme.shapes.medium,
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(20.dp)) {
                Icon(
                    Icons.Rounded.Fingerprint,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(36.dp)
                )
                Spacer(Modifier.height(12.dp))
                Text("How it works", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(8.dp))
                Text(
                    "1. Gently cover the rear camera and the flash together with one fingertip.\n" +
                        "2. Press start. The flash lights up your finger and the camera watches the tiny brightness changes each heartbeat causes.\n" +
                        "3. Hold still and breathe normally — it takes about 30 seconds.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = onStart,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
        ) { Text("Start measuring") }
        TextButton(onClick = onWearable) {
            Text("Wearing a watch or ring? Read from it instead \u2192")
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "Works best sitting down, with a warm fingertip and light pressure. Thick cases can block the flash.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun MeasuringView(
    bpm: Int?,
    quality: HeartRateProcessor.Quality,
    waveform: List<Float>,
    progress: Float,
    onCancel: () -> Unit
) {
    val pulse = rememberInfiniteTransition(label = "heartbeat")
    val heartScale by pulse.animateFloat(
        initialValue = 1f,
        targetValue = 1.18f,
        animationSpec = infiniteRepeatable(tween(500), RepeatMode.Reverse),
        label = "heartScale"
    )
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(20.dp))
        Icon(
            Icons.Rounded.Favorite,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier
                .size(40.dp)
                .graphicsLayer {
                    scaleX = heartScale
                    scaleY = heartScale
                }
        )
        Spacer(Modifier.height(10.dp))
        Text(
            bpm?.toString() ?: "\u00b7 \u00b7 \u00b7",
            style = MaterialTheme.typography.displayLarge
        )
        Text(
            "beats per minute",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(20.dp))
        Surface(
            shape = MaterialTheme.shapes.medium,
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(16.dp)) {
                WaveLine(
                    waveform,
                    Modifier
                        .fillMaxWidth()
                        .height(96.dp)
                )
            }
        }
        Spacer(Modifier.height(14.dp))
        Text(
            hintFor(quality),
            style = MaterialTheme.typography.bodyMedium,
            color = if (quality == HeartRateProcessor.Quality.GOOD) MaterialTheme.colorScheme.primary
            else MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(14.dp))
        LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(18.dp))
        OutlinedButton(
            onClick = onCancel,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) { Text("Cancel") }
    }
}

@Composable
private fun DoneView(
    finalBpm: Int?,
    saved: Boolean,
    onSave: () -> Unit,
    onAgain: () -> Unit,
    onBreathe: () -> Unit
) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(24.dp))
        if (finalBpm != null) {
            Text("$finalBpm", style = MaterialTheme.typography.displayLarge, color = MaterialTheme.colorScheme.primary)
            Text(
                "beats per minute",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(14.dp))
            Text(
                contextLine(finalBpm),
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center
            )
        } else {
            Text("No stable reading", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(10.dp))
            Text(
                "That happens — try again with a warm fingertip, lighter pressure and no movement. Remove thick phone cases.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
        Spacer(Modifier.height(22.dp))
        if (finalBpm != null) {
            Button(
                onClick = onSave,
                enabled = !saved,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
            ) { Text(if (saved) "Saved \u2713" else "Save reading") }
            Spacer(Modifier.height(10.dp))
        }
        OutlinedButton(
            onClick = onAgain,
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
        ) { Text("Measure again") }
        TextButton(onClick = onBreathe) { Text("Slow it down with breathing \u2192") }
        Spacer(Modifier.height(10.dp))
        Text(
            "This is an estimate from your phone's camera, not a medical measurement. If you have chest pain or pressure, pain spreading to your arm, jaw or back, or symptoms that feel different from your usual panic, contact emergency services.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}

private fun hintFor(q: HeartRateProcessor.Quality): String = when (q) {
    HeartRateProcessor.Quality.NO_FINGER -> "Cover the camera lens and the flash fully with your fingertip."
    HeartRateProcessor.Quality.SETTLING -> "Reading\u2026 keep still and breathe normally."
    HeartRateProcessor.Quality.WEAK -> "Weak signal — try slightly lighter pressure and a warm finger."
    HeartRateProcessor.Quality.GOOD -> "Good signal \u2713"
}

private fun contextLine(bpm: Int): String = when {
    bpm < 60 -> "Below the typical resting range of 60\u2013100. If you feel faint or this persists, check in with a clinician."
    bpm <= 100 -> "Within the typical resting range of 60\u2013100 bpm."
    bpm <= 130 -> "Elevated — very common during anxiety and panic. It comes back down as you slow your breathing."
    else -> "High — panic can genuinely push your heart this fast, and it settles as the wave passes. If it doesn't come down, seek medical care."
}

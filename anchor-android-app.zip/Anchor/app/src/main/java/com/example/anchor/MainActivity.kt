package com.example.anchor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.anchor.ui.BreathingScreen
import com.example.anchor.ui.CalmScreen
import com.example.anchor.ui.GroundingScreen
import com.example.anchor.ui.HistoryScreen
import com.example.anchor.ui.HomeScreen
import com.example.anchor.ui.PulseScreen
import com.example.anchor.ui.SettingsScreen
import com.example.anchor.ui.WearableScreen
import com.example.anchor.ui.theme.AnchorTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AnchorTheme {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background)
                ) {
                    AnchorApp()
                }
            }
        }
    }
}

@Composable
fun AnchorApp() {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = "home") {
        composable("home") { HomeScreen(nav) }
        composable("calm") { CalmScreen(nav) }
        composable("pulse") { PulseScreen(nav) }
        composable("wearable") { WearableScreen(nav) }
        composable("breathe") { BreathingScreen(nav) }
        composable("ground") { GroundingScreen(nav) }
        composable("history") { HistoryScreen(nav) }
        composable("settings") { SettingsScreen(nav) }
    }
}

package com.example.anchor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.anchor.ui.BreathingScreen
import com.example.anchor.ui.CalmScreen
import com.example.anchor.ui.GroundingScreen
import com.example.anchor.ui.HistoryScreen
import com.example.anchor.ui.HomeScreen
import com.example.anchor.ui.PulseScreen
import com.example.anchor.ui.SettingsScreen
import com.example.anchor.ui.WearableScreen
import com.example.anchor.ui.theme.AnchorTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AnchorTheme {
                // Surface (not Box) establishes the default content color, so text
                // and icons without an explicit color render as onBackground instead
                // of black. The inner width cap keeps layouts phone-shaped and
                // centered on tablets and foldables.
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
                        Box(
                            Modifier
                                .widthIn(max = 500.dp)
                                .fillMaxSize()
                        ) {
                            AnchorApp()
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AnchorApp() {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = "home") {
        composable("home") { HomeScreen(nav) }
        composable("calm") { CalmScreen(nav) }
        composable("pulse") { PulseScreen(nav) }
        composable("wearable") { WearableScreen(nav) }
        composable("breathe") { BreathingScreen(nav) }
        composable("ground") { GroundingScreen(nav) }
        composable("history") { HistoryScreen(nav) }
        composable("settings") { SettingsScreen(nav) }
    }
}

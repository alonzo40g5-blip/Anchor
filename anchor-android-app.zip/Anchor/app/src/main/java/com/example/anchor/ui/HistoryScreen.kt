package com.example.anchor.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.anchor.data.DataStore

@Composable
fun HistoryScreen(nav: NavController) {
    val context = LocalContext.current
    val episodes = remember { DataStore.episodes(context).toMutableStateList() }
    val readings = remember { DataStore.readings(context).toMutableStateList() }

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
    ) {
        ScreenHeader("History") { nav.popBackStack() }
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 24.dp)
        ) {
            item { SectionLabel("Panic episodes") }
            if (episodes.isEmpty()) {
                item { EmptyHint("No episodes logged yet — that's a good thing.") }
            }
            items(episodes, key = { "e${it.time}" }) { e ->
                Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surface) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(formatTime(e.time), style = MaterialTheme.typography.titleLarge)
                            Text(
                                "Intensity ${e.intensity}/10" + (e.bpm?.let { " \u00b7 $it bpm" } ?: ""),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                            if (e.symptoms.isNotEmpty()) {
                                Text(
                                    e.symptoms.joinToString(" \u00b7 "),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (e.notes.isNotBlank()) {
                                Text(
                                    e.notes,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        IconButton(onClick = {
                            DataStore.deleteEpisode(context, e.time)
                            episodes.remove(e)
                        }) {
                            Icon(
                                Icons.Rounded.Delete,
                                contentDescription = "Delete episode",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
            item { SectionLabel("Pulse readings") }
            if (readings.isEmpty()) {
                item { EmptyHint("No saved readings yet.") }
            }
            items(readings, key = { "r${it.time}" }) { r ->
                Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surface) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Rounded.Favorite,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text("${r.bpm} bpm", style = MaterialTheme.typography.titleLarge)
                            Text(
                                formatTime(r.time) + " \u00b7 " + (if (r.source == "watch") "Watch/ring" else "Camera"),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = {
                            DataStore.deleteReading(context, r.time)
                            readings.remove(r)
                        }) {
                            Icon(
                                Icons.Rounded.Delete,
                                contentDescription = "Delete reading",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

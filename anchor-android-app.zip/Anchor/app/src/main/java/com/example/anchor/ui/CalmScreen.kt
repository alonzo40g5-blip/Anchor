@file:OptIn(
    androidx.compose.foundation.layout.ExperimentalLayoutApi::class,
    androidx.compose.material3.ExperimentalMaterial3Api::class
)

package com.example.anchor.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.anchor.data.DataStore
import kotlin.math.roundToInt

private val SymptomOptions = listOf(
    "Racing heart", "Short of breath", "Chest tightness", "Dizziness", "Trembling",
    "Sweating", "Nausea", "Tingling", "Feeling unreal", "Fear of losing control"
)

private val symptomsSaver = listSaver<SnapshotStateList<String>, String>(
    save = { it.toList() },
    restore = { it.toMutableStateList() }
)

/**
 * The "I'm panicking" flow: reassure -> breathe -> ground -> log.
 * Deliberately one thing per screen, big touch targets, no reading walls.
 */
@Composable
fun CalmScreen(nav: NavController) {
    var step by rememberSaveable { mutableStateOf(0) }
    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp)
        ) {
            IconButton(onClick = { nav.popBackStack() }) {
                Icon(Icons.Rounded.Close, contentDescription = "Close")
            }
            Spacer(Modifier.weight(1f))
            Dots(step, 4)
            Spacer(Modifier.weight(1f))
            Spacer(Modifier.width(48.dp))
        }
        when (step) {
            0 -> ReassureStep { step = 1 }
            1 -> BreatheStep { step = 2 }
            2 -> GroundingContent(Modifier.weight(1f)) { step = 3 }
            else -> LogStep(nav)
        }
    }
}

@Composable
private fun ReassureStep(onNext: () -> Unit) {
    val glow = rememberInfiniteTransition(label = "glow")
    val glowScale by glow.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(2400), RepeatMode.Reverse),
        label = "glowScale"
    )
    Column(
        Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.weight(1f))
        Box(contentAlignment = Alignment.Center) {
            Box(
                Modifier
                    .size(150.dp)
                    .scale(glowScale)
                    .background(
                        Brush.radialGradient(
                            listOf(
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.30f),
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.0f)
                            )
                        ),
                        CircleShape
                    )
            )
            Icon(
                Icons.Rounded.Favorite,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(46.dp)
            )
        }
        Spacer(Modifier.height(24.dp))
        Text("You're safe.", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))
        Text(
            "This is a panic attack. It feels overwhelming, but it is not dangerous " +
                "and it will pass — usually the peak lasts only a few minutes.\n\n" +
                "You don't have to fight it. Let's ride it out together.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.weight(1f))
        Button(
            onClick = onNext,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
        ) { Text("Breathe with me") }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun BreatheStep(onNext: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Spacer(Modifier.height(4.dp))
        Text(
            "Follow the circle",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        Text(
            "Long, slow exhales tell your body the danger has passed.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 6.dp)
        )
        BreathingContent(
            Modifier.weight(1f),
            autoStart = true,
            showTechniquePicker = false
        )
        Button(
            onClick = onNext,
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
        ) { Text("I'm ready to continue") }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun LogStep(nav: NavController) {
    val context = LocalContext.current
    var intensity by rememberSaveable { mutableStateOf(6f) }
    var notes by rememberSaveable { mutableStateOf("") }
    val symptoms = rememberSaveable(saver = symptomsSaver) { SnapshotStateList<String>() }
    var savedStep by rememberSaveable { mutableStateOf(false) }
    val recentReading = remember { DataStore.latestRecentReading(context, 15 * 60_000L) }

    if (savedStep) {
        AfterSave(nav)
        return
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Text("Log this episode?", style = MaterialTheme.typography.headlineMedium)
        Text(
            "A short record helps you and any clinician spot patterns. Totally optional.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 6.dp)
        )
        SectionLabel("How intense was it? (${intensity.roundToInt()}/10)")
        Slider(
            value = intensity,
            onValueChange = { intensity = it },
            valueRange = 1f..10f,
            steps = 8
        )
        SectionLabel("What did you feel?")
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            SymptomOptions.forEach { s ->
                FilterChip(
                    selected = s in symptoms,
                    onClick = { if (s in symptoms) symptoms.remove(s) else symptoms.add(s) },
                    label = { Text(s) }
                )
            }
        }
        SectionLabel("Notes (optional)")
        OutlinedTextField(
            value = notes,
            onValueChange = { notes = it },
            minLines = 3,
            placeholder = { Text("Where were you? What was happening?") },
            modifier = Modifier.fillMaxWidth()
        )
        if (recentReading != null) {
            Spacer(Modifier.height(10.dp))
            Text(
                "A pulse reading from the last 15 minutes (${recentReading.bpm} bpm, " +
                    (if (recentReading.source == "watch") "watch/ring" else "camera") +
                    ") will be attached automatically.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.height(18.dp))
        Button(
            onClick = {
                DataStore.addEpisode(
                    context,
                    DataStore.Episode(
                        time = System.currentTimeMillis(),
                        intensity = intensity.roundToInt(),
                        symptoms = symptoms.toList(),
                        bpm = recentReading?.bpm,
                        notes = notes.trim()
                    )
                )
                savedStep = true
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
        ) { Text("Save episode") }
        TextButton(
            onClick = { nav.popBackStack() },
            modifier = Modifier.align(Alignment.CenterHorizontally)
        ) { Text("Skip") }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun AfterSave(nav: NavController) {
    Column(
        Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.weight(1f))
        Icon(
            Icons.Rounded.Check,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(52.dp)
        )
        Spacer(Modifier.height(16.dp))
        Text("Logged. You got through it.", style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))
        Text(
            "Be gentle with yourself for the rest of the day — water, food, rest. " +
                "Panic is exhausting, and you just handled it.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.weight(1f))
        Button(
            onClick = { nav.popBackStack() },
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
        ) { Text("Back home") }
        Spacer(Modifier.height(20.dp))
    }
}

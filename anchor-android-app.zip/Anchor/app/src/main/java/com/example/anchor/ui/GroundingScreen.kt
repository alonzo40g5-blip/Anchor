package com.example.anchor.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Spa
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

data class GroundStep(val count: Int, val sense: String, val prompt: String)

val GroundSteps = listOf(
    GroundStep(5, "things you can see", "Look around slowly. Name each one silently — its colour, its shape, where it sits."),
    GroundStep(4, "things you can feel", "Your feet on the floor. Fabric on your skin. The temperature of the air."),
    GroundStep(3, "things you can hear", "Near or far — traffic, a fan, your own breathing."),
    GroundStep(2, "things you can smell", "Or two smells you like, if none are around right now."),
    GroundStep(1, "thing you can taste", "A sip of water counts. Notice it properly.")
)

@Composable
fun GroundingScreen(nav: NavController) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
    ) {
        ScreenHeader("Grounding") { nav.popBackStack() }
        GroundingContent(Modifier.weight(1f)) { nav.popBackStack() }
    }
}

/**
 * 5-4-3-2-1: walking the senses pulls attention out of the spiral
 * and back into the room. Reusable inside the guided calm flow.
 */
@Composable
fun GroundingContent(modifier: Modifier = Modifier, onComplete: () -> Unit) {
    var index by rememberSaveable { mutableStateOf(0) }
    Column(
        modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (index < GroundSteps.size) {
            val step = GroundSteps[index]
            Spacer(Modifier.weight(1f))
            Text(
                "${step.count}",
                style = MaterialTheme.typography.displayLarge,
                color = MaterialTheme.colorScheme.primary
            )
            Text(step.sense, style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center)
            Spacer(Modifier.height(16.dp))
            Text(
                step.prompt,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 12.dp)
            )
            Spacer(Modifier.weight(1f))
            Dots(index, GroundSteps.size)
            Spacer(Modifier.height(20.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                if (index > 0) {
                    OutlinedButton(
                        onClick = { index-- },
                        modifier = Modifier
                            .weight(1f)
                            .height(54.dp)
                    ) { Text("Back") }
                }
                Button(
                    onClick = { index++ },
                    modifier = Modifier
                        .weight(1f)
                        .height(54.dp)
                ) { Text(if (index == GroundSteps.size - 1) "Finish" else "Next") }
            }
            Spacer(Modifier.height(20.dp))
        } else {
            Spacer(Modifier.weight(1f))
            Icon(
                Icons.Rounded.Spa,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(52.dp)
            )
            Spacer(Modifier.height(16.dp))
            Text("Well anchored.", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(10.dp))
            Text(
                "Notice — is your body even a little calmer than a few minutes ago? That's the wave passing.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.weight(1f))
            Button(
                onClick = {
                    index = 0
                    onComplete()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
            ) { Text("Continue") }
            Spacer(Modifier.height(20.dp))
        }
    }
}

# Anchor — a panic attack companion for Android

Anchor is a native Android app (Kotlin + Jetpack Compose) built for the moment a panic attack hits. It measures your pulse two ways — with the phone's camera, or from a watch/ring via Health Connect — and walks you through evidence-based calming techniques.

## Features

- **"I'm panicking" guided flow** — one big button on the home screen leads through four gentle steps: reassurance, paced breathing, 5-4-3-2-1 grounding, and an optional episode log.
- **Camera pulse (PPG)** — put a fingertip over the rear camera + flash; the app detects the tiny brightness changes each heartbeat causes and estimates BPM with a live waveform, signal-quality feedback and a 30-second measurement window.
- **Watch & ring vitals (Health Connect)** — reads heart rate (with a last-hour sparkline), resting heart rate, HRV (RMSSD), blood oxygen and respiratory rate synced by Pixel Watch, Galaxy Watch/Ring, Fitbit, Garmin, Oura and any other device that writes to Health Connect.
- **Breathing exercises** — 4-7-8, box breathing, and slow 5·5 with an animated pacing circle, per-second countdown and soft haptic ticks (usable eyes-closed).
- **Grounding** — the classic 5-4-3-2-1 senses exercise, one step per screen.
- **Episode log** — intensity, symptoms, notes; recent pulse readings (camera or watch) attach automatically. Useful for spotting patterns or sharing with a clinician.
- **Trusted contact** — one tap opens the dialer with a person you chose in advance.
- **Calm design** — dark, low-arousal palette; large touch targets; no walls of text mid-panic.

## Project structure

```
Anchor/
├── settings.gradle / build.gradle / gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle
    └── src/main/
        ├── AndroidManifest.xml
        ├── res/                      # theme, strings, launcher icon
        └── java/com/example/anchor/
            ├── MainActivity.kt       # navigation graph
            ├── PermissionsRationaleActivity.kt
            ├── data/DataStore.kt     # on-device JSON store
            ├── ppg/HeartRate.kt      # camera PPG signal processing
            ├── health/WearableHealth.kt  # Health Connect reads
            └── ui/                   # all Compose screens + theme
```

## How the camera pulse works

Photoplethysmography (PPG): with the flash on and a fingertip over the lens, each heartbeat pushes slightly more blood into the finger, which absorbs slightly more light. `HeartRate.kt` averages the frame brightness, removes slow drift with a moving average, detects peaks with an adaptive threshold and refractory period, and converts the median inter-beat interval to BPM.

Accuracy tips: warm finger, light pressure, sit still, remove thick cases. It's an estimate, not a medical measurement.

## How the watch / ring integration works

Anchor reads from **Health Connect**, Android's shared health-data layer (built into Android 14+, installable from the Play Store on Android 9–13). Your wearable's own app (Fitbit, Samsung Health, Garmin Connect, Oura, etc.) syncs measurements into Health Connect; Anchor reads them with your explicit, revocable permission.

Setup on a real device:
1. Make sure your watch/ring's companion app is set to sync with Health Connect (usually a toggle inside that app's settings).
2. In Anchor, open **Watch & ring** and tap **Connect Health Connect**.
3. Grant the read permissions you're comfortable with (heart rate is the only one Anchor needs).

**Important caveat:** Health Connect data arrives by *sync*, not live streaming, so readings can lag a few minutes behind your wrist. Anchor shows how old each reading is and suggests the camera pulse when data is stale. True live streaming from a Wear OS watch would need a small companion watch app using Health Services' `MeasureClient` — a natural next step for this project.

## Building & running

1. Open the `Anchor` folder in a recent Android Studio (Koala or newer, JDK 17).
2. Let Gradle sync. If the IDE complains about a missing `gradle-wrapper.jar`, either let Android Studio regenerate the wrapper, or run `gradle wrapper --gradle-version 8.7` once, or copy the `gradle-wrapper.jar` from any other project into `gradle/wrapper/`.
3. Run on a **physical phone** — the camera PPG and Health Connect don't work meaningfully on the emulator.

Versions used: AGP 8.5.2, Kotlin 1.9.24, Compose BOM 2024.06.00, CameraX 1.3.4, Health Connect client 1.1.0-alpha07, min SDK 26, target SDK 34.

## Permissions

- `CAMERA` — pulse measurement only; no photos are captured or stored.
- `VIBRATE` — soft haptics that pace the breathing exercise.
- `android.permission.health.READ_*` — Health Connect reads (heart rate, resting HR, HRV, SpO₂, respiratory rate), requested only when you tap Connect.

## Privacy

Everything Anchor stores lives in a single JSON file in the app's private storage. Nothing is uploaded anywhere. Health Connect access is read-only and revocable at any time in Health Connect settings.

## Disclaimer

Anchor is a self-help companion, **not a medical device**. Camera and wearable readings are estimates and can't diagnose anything. Chest pain or pressure, pain spreading to the arm/jaw/back, fainting, or symptoms unlike your usual panic warrant contacting emergency services. Panic disorder is very treatable — if attacks are frequent or limiting, a doctor or therapist can genuinely help.

## Ideas to extend

- Wear OS companion app for live heart-rate streaming (`MeasureClient`).
- CSV export of the episode log for clinicians.
- A home-screen widget or quick-settings tile for the calm flow.
- Rename the package from `com.example.anchor` before publishing anywhere.
